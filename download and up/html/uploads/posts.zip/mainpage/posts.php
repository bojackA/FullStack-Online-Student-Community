<?php
session_start();
include_once "../php/config.php";



if(isset($_POST['posts'])){
    $text = $_POST['content'];
    $id=$_SESSION['unique_id'];
    $pic = $_POST['pic'];


    if (empty($pic)) {


        $sql = "INSERT INTO posts(pid,text) 
    VALUES('$id','$text')";

        $result = mysqli_query($conn, $sql);

        if ($result) {
            echo "<script> alert('posted successfully'); </script>";
        } else {
            echo "failed to post";
        }
    }
    else {
        $sql2 = "INSERT INTO post_img(id,text,img) 
    VALUES('$id','$text','$pic')";
    $result2 = mysqli_query($conn, $sql2);

    if ($result2) {
        echo "<script> alert('posted successfully'); </script>";
    } else {
        echo "failed to post";
    }

    }
}