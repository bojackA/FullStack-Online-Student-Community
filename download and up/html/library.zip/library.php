<?php

$host="localhost";
$username="root";
$password="";
$db="file_upload";

$connection= new mysqli($host,$username,$password,$db);
$sql_query1 = "TRUNCATE TABLE LIBRARY";

if($connection->query($sql_query1) === true){
    echo "dELETED";
}

else{
    echo "some error occured1";
}
$sql_query = "INSERT library select * FROM pl WHERE idf=1";

if($connection->query($sql_query) === true){
    echo "data copied successfully";
}
else{
    echo "some error occured";
}

?>