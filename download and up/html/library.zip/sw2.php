<?php include 'filesLogic.php';?><?php
session_start();
include_once "../php/config.php";

            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
        
            

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sw2</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/file.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a class="logo"> <i class="fas fa-graduation-cap"></i>CollegCom</a>

    <div id="menu-btn" class="fas fa-bars"></div>

    <nav class="navbar">
        <ul>
            <li><a href="./main.html">home</a></li>
            <li><a href="./course-2.html">courses</a>
            </li>
            <li><a>pages </a>
                <ul>
                    <li><a href="#">GPA Calculeter</a></li>
                    <li><a href="#">FAQ</a></li>
                </ul>
            </li>
        </ul>
    </nav>

</header>
<section class="heading">
    <h3>SW2</h3>
    <p> <a href="./course-2.html">Courses >></a> SW2 </p>
</section>
<div class="wrapper">
    <header>File Uploader</header>
    <form action="sw2.php" method="post" enctype="multipart/form-data" >
      <input class="file-input" type="file" id="file" name="myfile" hidden>
      <i class="fas fa-cloud-upload-alt"></i>
      <label for="file">Browse File and click upload to Uploaded</label>
      <button type="submit" name="save">upload</button>
    </form>
     </div> 
</div>
 <table>
<thead>
    <th>Filename</th>
    <th>size (in mb)</th>
    <th>Downloads</th>
    <th>Action</th>
    <th>Add to library<tH>
</thead>
<tbody>
  <?php foreach ($files as $file): ?>
    <tr>
      <td><?php echo $file['name']; ?></td>
      <td><?php echo floor($file['size'] / 1000) . ' KB'; ?></td>
      <td><?php echo $file['downloads']; ?></td>
      <td><a href="sw2.php?file_id=<?php echo 
      $file['id'] ?>">Download</a></td>   
    <td> <button type="submit" name="ADD">Add To My Library</button></td> 
</tr>
    <?php endforeach;?>
    

</tbody>
    </body>
  </html>
  
    