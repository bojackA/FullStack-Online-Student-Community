<!DOCTYPE html>
<html lang="eng">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width,intial-scale=1.0">
        <title>Page</title>
        <link rel="stylesheet" href="../css/page.css">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.6/css/unicons.css">

    </head>
    <body>
        
      <nav>
        <div class="container">
            <a href="../MyProfile/My_Profile.php">
            <h2 class="log">CollegeCom</h2>
            </a>
            <div class="search-bar">
                <i class="uil uil-search"></i>
                <input type="search" placeholder="search">
            </div>
        </div>
      </nav>
      <main>
        <div class="container">
            <div class="left">
            <a class="profile">
                <div class="profile-photo">
                <img src="../images/user.png">
                </div>
                <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
            ?>
                <div class="handle">
                <h4><?php echo $row['fname']; ?></h4>
                    <p class="text-muted">
                    <?php echo $row['email']; ?>
                    </p>
                  
                </div>
                <a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
            </a>
            <div class="sidebar">
                <a class="menu-items active">
                    <span><i class="uil uil-home"></i></span><h3>Home</h3>
                    </a>
                    <a class="menu-items" id ='notifications'>
                    <span><i class="uil uil-bell"><samll class="notification-count">+4</samll></i></span><h3>Notifications</h3>
                    <div class='notifications-popup'>
                    <div>
                        <div class="profile-photo">
                            <img src="../images/user.png">
                        </div>
                        <div class="notification-body">
                            <b>mouhammad mousa</b> accept your friend request
                            <small class="text-muted">2 Days AGO</small>
                        </div>
                    </div>
                    <div>
                        <div class="profile-photo">
                            <img src="../images/user.png">
                        </div>
                        <div class="notification-body">
                            <b>Amer Sawan</b> comment on your post
                            <small class="text-muted"> 1 Hours AGO</small>
                        </div>
                    </div>
                    <div>
                        <div class="profile-photo">
                            <img src="../images/user.png">
                        </div>
                        <div class="notification-body">
                            <b>Loay Takwa</b> and <b>30 others </b> liked your post
                            <small class="text-muted">2 Days AGO</small>
                        </div>
                    </div>
                    <div>
                        <div class="profile-photo">
                            <img src="../images/user.png">
                        </div>
                        <div class="notification-body">
                            <b>Maha dabagh</b> Comment on your post
                            <small class="text-muted">2 Days AGO</small>
                        </div>
                    </div>
                    </div>
                    </a>
                    <a class="menu-items" id="messages-notifications">
                    <span><i class="uil uil-envelope-alt">
                    <a href="../html/user.html">Message Now</a>
                    <small class="notification-count">6</small></i></span>
                    </a>
                    <a class="menu-items">
                    <span><i class="uil uil-bookmark"></i></span><h3>Bookmark</h3>
                    </a>
                    <a class="menu-items">
                    <span><i class="uil uil-palette"></i></span><h3>Thems</h3>
                    </a>
                    <a class="menu-items">
                    <span><i class="uil uil-setting"></i></span><h3>Settings</h3>
                </a>
            </div>
        </div>

            <div class="middle">
                    <div class="containers">
                        <div class="wrappers">
                            <section class="posts">
                                <header> Create Post</header>
                                <form action="#">
                                    <div class="contents">
                                         <img src="../images/user.png">
                                        <div class="detailss">
                                            <p>Hala Akkad</p>
                                            </div>
                                        </div>
                                   <textarea placeholder="Write your post" required></textarea>
                                   <div class="ops">
                                    <p>Add to your post</p>
                                    <ul class="list">
                                        <input type="file" id="file" accept="image/*">
                                        <label for="file" id="upload"><i class="uil uil-camera"></i></label>
                                        <!--<li> <i class="	far fa-file-pdf"></i> </li>-->
                                    </ul>
                                   </div>
                                   <button>Post</button>
                                </form>
                    
                    
                            </section>   
                            </div>
                            </div>
                            <div class="post">
                                <div class="post-top">
                                    <div class="dp">
                                        <img src="../images/user.png" alt="">
                                    </div>
                                    <div class="post-info">
                                        <p class="name">Hala Akkad</p>
                                        
                                    </div>
                                    <i class="uil uil-edit"></i>
                                    <span class="uil uil-multiply"></span>
                                </div>
                
                                <div class="post-content">
                                   baby shark dododo baby shark baby shark <br>
                                   baby shark dododo baby shark dodoododo<br>
                                    baby shark :p
                                </div>
                                
                                <div class="post-bottom">
                                    <div class="action">
                                        <i class=""></i>
                                        <span></span>
                                    </div>
                                    <div class="action">
                                        <i class=""></i>
                                        <span></span>
                                    </div>
                                    <div class="action">
                                        <i class=""></i>
                                        <span></span>
                                    </div>
                                </div>
                                <div class="comment-site">
                                    <div class="profile-photo">
                                        <a href="#" id="profile-link">
                                            <img id="Profile_images" src="../images/user.png">
                                        </a>
                                    </div>
                                    <div class="comment-input">
                                        <input type="text" placeholder="Write a comment…">
                                        <div class="comment-icon">
                                        </div>
                                    </div>
                                </div>
                                <div class="com">
                                    <div class="com-top">
                                        <div class="cc">
                                            <img src="../images/user.png" alt="">
                                        </div>
                                        <div class="comm-info">
                                            <p class="names">Hala Akkad</p>
                                            <span class="comm">ok so baby shark do do do dododo baby shark </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                
                            <div class="post">
                                <div class="post-top">
                                    <div class="dp">
                                        <img src="../images/user.png" alt="">
                                    </div>
                                    <div class="post-info">
                                        <p class="name">Hala Akkad</p>
                                    </div>
                                    <i class="uil uil-edit"></i>
                                    <span class="uil uil-multiply"></span>
                                </div>
                
                                <div class="post-content">
                                   Hello it's ME
                                    <img src="../images/upload.png" />
                                </div>
                                
                                <div class="post-bottom">
                                    <div class="action">
                                        <i class=""></i>
                                        <span></span>
                                    </div>
                                    <div class="action">
                                        <i class=""></i>
                                        <span></span>
                                    </div>
                                    <div class="action">
                                        <i class=""></i>
                                    </div>
                                </div>
                                <div class="comment-site">
                                    <div class="profile-photo">
                                        <a href="#" id="profile-link">
                                            <img id="Profile_images" src="../images/user.png">
                                        </a>
                                    </div>
                                    <div class="comment-input">
                                        <input type="text" placeholder="Write a comment…">
                                        <div class="comment-icon">
                                        </div>
                                    </div>
                                </div>
                                <div class="com">
                                    <div class="com-top">
                                        <div class="cc">
                                            <img src="../images/user.png" alt="">
                                        </div>
                                        <div class="comm-info">
                                            <p class="names">Hala Akkad</p>
                                            <span class="comm">ok so baby shark do do do dododo baby shark </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                
            </div>
            <div class="right">
                <div class="messages">
                    <div class="heading">
                        <h4>Messages</h4><i class="uil uil-edit"></i>
                    </div>
                    <div class="search-bar">
                        <i class="uil uil-search"></i>
                        <input type="search" placeholder="search messages" id="message-search">
                    </div>
                    <div class="category">
                        <h6 class="active">primary</h6>
                        <h6>General</h6>
                        <h6 class="message-requests">Request(3)</h6>
                    </div>
                    <div class="message">
                        <div class="profile-photo">
                            <img src="../images/user.png">
                        </div>
                        <div class="message-body">
                            <h5>Amer sawan</h5>
                            <p class="text-bold">2 new messages</p>
                        </div>
                        
                    </div>
                    <div class="message">
                        <div class="profile-photo">
                            <img src="../images/user.png">
                            <div class="active"></div>
                        </div>
                        <div class="message-body">
                            <h5>maha dabbagh</h5>
                            <p class="text-muted">ok see u</p>
                        </div>
                        
                    </div>
                    <div class="message">
                        <div class="profile-photo">
                            <img src="../images/user.png">
                        </div>
                        <div class="message-body">
                            <h5>mohammad mousa</h5>
                            <p class="text-bold">are u ready!!</p>
                        </div>
                        
                    </div>
                    
                </div>
                <div class="friend-requests">
                    <h4>Requests</h4>
                    <div class="request">
                        <div class="info">
                            <div class="profile-photo">
                                <img src="../images/user.png">
                                
                            </div>
                            <div>
                                <h5>Hiba Akkad</h5>
                                <p class="text-muted">
                                    6 mutual friends
                                </p>
                                
                            </div>
                        </div>
                        <div class="action">
                            <button class="btn btn-primary">
                                Accept
                            </button>
                            <button class="btn">
                              Decline
                            </button>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
      </main>
    
    </body>
</html>